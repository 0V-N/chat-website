from flask import Flask, request, render_template
from flask_cors import CORS
import openai

app = Flask(__name__)
CORS(app)
app.debug = True

openai.api_key = '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'

@app.route('/')
def home():
    return 'Welcome to the chatbot!'

@app.route('/chat', methods=['GET', 'POST'])
def chat():
    message = request.json['message']

    # Call the OpenAI API to generate a response
    response = openai.Completion.create(
        engine='text-davinci-003',
        prompt=message,
        max_tokens=50,
        temperature=0.7
    )

    # Render an HTML template with the response
    return render_template('response.html', response=response.choices[0].text.strip())

if __name__ == '__main__':
    app.run()
